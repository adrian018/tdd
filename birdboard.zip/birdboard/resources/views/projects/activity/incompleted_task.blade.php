You incompleted "{{ $activity->subject->body }}"
